This app generates a SHA-Code with or without Salt. Salt is a randomly hex-number, which makes your code unpossible to hack. But it must not be a word, you can enter whole sentences. There is no character-limit!

Music by Palrom